package med.voll.api.domain.medico;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

/*Gestion de la base de datos CRUD de manera automatica*/ 
								/*Tipo de entidad que guardaremos en la DB y tipo de dato que es el ID*/
public interface MedicoRepository extends JpaRepository<Medico, Long>{

	Page<Medico> findByActivoTrue(Pageable paginacion); /*Datos medico con su id*/
	
}
