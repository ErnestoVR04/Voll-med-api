package med.voll.api.domain.usuarios;

//DTO de autenticacion de usuarios
public record DatosAutenticacionUsuario(String login, String clave) {

}
