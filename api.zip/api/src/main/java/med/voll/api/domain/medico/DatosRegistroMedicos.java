package med.voll.api.domain.medico;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import med.voll.api.domain.direccion.DatosDireccion;

/*Registro de los datos de los request de los medicos*/
/*Especialidad clase tipo enum que lista los tipos de especialidad*/
/*DatosDireccion clase tipo record que almacena los datos de la direccion de la api*/

/*DTO = DATA TRASNFER OBJECT, sirve para recibir y enviar los datos que recibe la api desde el cliente a la db y visceversa*/
public record DatosRegistroMedicos(
		
		@NotBlank /*Notblank incluye tambien NotNull*/
		String nombre, 
		
		@NotBlank
		@Email /*Vlida el formato de email*/
		String email, 
		
		@NotBlank
		String telefono,
		
		@NotBlank
		@Pattern(regexp="\\d{4,6}") /*Limita el formato a 4-6 numeros*/
		String documento, 
		
		@NotNull
		Especialidad especialidad, 
		
		@NotNull
		@Valid /*Valida los datos de direccion*/
		DatosDireccion direccion) { /*Deben ser llamados igual que en insomnia*/

}
