package med.voll.api.domain.medico;

//DTO
/*Encargado de traer los datos de la db*/
/*Record de datos que se listaran*/
public record DatosListadoMedicos(Long id, String nombre, Especialidad especialidad, String documento, String email) {
	
	public DatosListadoMedicos(Medico medico) { /*Constructor*/
		this(medico.getId(), medico.getNombre(), medico.getEspecialidad(), medico.getDocumento(), medico.getEmail());
	}
	
}
