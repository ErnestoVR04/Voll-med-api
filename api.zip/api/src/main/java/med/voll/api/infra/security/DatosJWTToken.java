package med.voll.api.infra.security;

//DTO
public record DatosJWTToken(String JWTtoken) {

}
