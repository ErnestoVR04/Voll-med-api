package med.voll.api.controller;

import java.net.URI;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;
import jakarta.transaction.Transactional;
import jakarta.validation.Valid;
import med.voll.api.domain.direccion.DatosDireccion;
import med.voll.api.domain.medico.DatosActualizarMedico;
import med.voll.api.domain.medico.DatosListadoMedicos;
import med.voll.api.domain.medico.DatosRegistroMedicos;
import med.voll.api.domain.medico.DatosRespuestaMedico;
import med.voll.api.domain.medico.Medico;
import med.voll.api.domain.medico.MedicoRepository;

@RestController
@RequestMapping("/medics") //Ruta de HTTP que sigue, localhost:8080/medics
public class MedicsController {
	
	@Autowired //Constructor
	private MedicoRepository medicoRepository;
	
	//DatosRegistroMedicos recibe los datos de la api
	//Medico persiste los datos de DatosRegistroMedicos
	//MedicoRepository Gestion de la base de datos de los datos persistidos por Medico
	
	@PostMapping //Post Guarda los datos del request de la api
	public ResponseEntity<DatosRespuestaMedico> registrarMedico(@RequestBody @Valid DatosRegistroMedicos datosRegistroMedicos, UriComponentsBuilder uriComponentsBuilder) { //@RequestBody cuerpo del request, Valida los parametros de validacion asignados en DatosRegistroMedico y DatosDireccion
		Medico medico = medicoRepository.save(new Medico(datosRegistroMedicos));
		DatosRespuestaMedico datosRespuestaMedico = new DatosRespuestaMedico(medico.getId(), medico.getNombre(), medico.getEmail(),
                medico.getTelefono(), medico.getEspecialidad().toString(),
                new DatosDireccion(medico.getDireccion().getCalle(), medico.getDireccion().getCiudad(), medico.getDireccion().getNumero(),
                    medico.getDireccion().getComplemento()));
		
		URI url = uriComponentsBuilder.path("/medics/{id}").buildAndExpand(medico.getId()).toUri();
		return ResponseEntity.created(url).body(datosRespuestaMedico);
		//Return 201 Created
		//URL donde encontrar el medico
	}
	
	//Page spring.data.domain
	@GetMapping //Get retorna datos de la db
	public ResponseEntity<Page<DatosListadoMedicos>> listadoMedicos(@PageableDefault(size=10) Pageable paginacion){ //Utilizaremos paginacion con 10 registros
		//return medicoRepository.findAll(paginacion).map(DatosListadoMedicos::new); Lista a todos los medicos de la bd
		return ResponseEntity.ok(medicoRepository.findByActivoTrue(paginacion).map(DatosListadoMedicos::new));
	}
	
	@PutMapping //Actualizar
	@Transactional //Realiza la transaccion de datos y al finalizar hace un commit
	public ResponseEntity<DatosRespuestaMedico> actualizarMedico(@RequestBody @Valid DatosActualizarMedico datosActualizarMedico) {
		Medico medico = medicoRepository.getReferenceById(datosActualizarMedico.id());
		medico.actualizarDatos(datosActualizarMedico);
		return ResponseEntity.ok(new DatosRespuestaMedico(medico.getId(), medico.getNombre(), medico.getEspecialidad().toString(), medico.getEmail(), medico.getTelefono(),
				new DatosDireccion(medico.getDireccion().getCiudad(), medico.getDireccion().getCalle(), medico.getDireccion().getNumero(), medico.getDireccion().getComplemento())));
	}
	
	//Delete logico, se queda en la base de datos mas ya no se muestra
	//ResponseEntity.noContent retorna un 204, queriendo decir que la transaccion fue exitosa y no se retorna ningun mensaje
	@DeleteMapping("/{id}")
	@Transactional
	public 	ResponseEntity eliminarMedico(@PathVariable Long id) {
		Medico medico = medicoRepository.getReferenceById(id);
		medico.desactivarMedico();
		return ResponseEntity.noContent().build();
	}
	
	@GetMapping("/{id}")
	@Transactional
	public ResponseEntity<DatosRespuestaMedico> retornarDatosMedico(@PathVariable Long id) {
		Medico medico = medicoRepository.getReferenceById(id);
		var datosMedico = new DatosRespuestaMedico(medico.getId(), medico.getNombre(), medico.getEmail(), medico.getTelefono(), medico.getEspecialidad().toString(), new DatosDireccion(medico.getDireccion().getCalle(), medico.getDireccion().getCiudad(), medico.getDireccion().getNumero(), medico.getDireccion().getComplemento()));
        return ResponseEntity.ok(datosMedico);
	}
	
	
	
	
	
	/*Eliminar por completo el registro de la base de datos
	@DeleteMapping("/{id}")
	@Transactional
	public void eliminarMedico(@PathVariable Long id) {
		Medico medico = medicoRepository.getReferenceById(id);
		medicoRepository.delete(medico);
	}
	*/ 
	
	
}
