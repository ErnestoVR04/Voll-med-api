package med.voll.api.domain.medico;


/*Especialidades*/
public enum Especialidad {
	ORTOPEDIA,
	CARDIOLOGIA,
	GINECOLOGIA,
	PEDIATRIA
}
