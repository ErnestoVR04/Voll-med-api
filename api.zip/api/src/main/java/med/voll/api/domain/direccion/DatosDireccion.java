package med.voll.api.domain.direccion;

import jakarta.validation.constraints.NotBlank;

/*DTO = DATA TRASNFER OBJECT, sirve para recibir los datos que recibe la api*/
public record DatosDireccion(

		@NotBlank String calle, @NotBlank String ciudad, @NotBlank String numero, @NotBlank String complemento) {

}
