package med.voll.api.domain.medico;

import jakarta.persistence.Embedded;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import med.voll.api.domain.direccion.Direccion;

/*Clase que realizara la persistencia de datos con la base de datos*/
@Table(name="medicos") /*nombre tabla*/
@Entity(name = "Medico")
@Getter
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(of="id")

public class Medico {
	
	
	@Id /*jakarta*/
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String nombre;
	private String email;
	private String telefono;
	private Boolean activo;
	private String documento;
	@Enumerated(EnumType.STRING)
	private Especialidad especialidad;
	@Embedded
	private Direccion direccion;
	
	
	public Medico(DatosRegistroMedicos datosRegistroMedicos) {
		this.nombre = datosRegistroMedicos.nombre();
		this.email = datosRegistroMedicos.email();
		this.telefono = datosRegistroMedicos.telefono();
		this.activo = true;
		this.documento = datosRegistroMedicos.documento();
		this.especialidad = datosRegistroMedicos.especialidad();
		this.direccion = new Direccion(datosRegistroMedicos.direccion());	
	}
	
	public void actualizarDatos(DatosActualizarMedico datosActualizarMedico) {
		if(datosActualizarMedico.nombre() != null){
			this.nombre = datosActualizarMedico.nombre();
		}
		
		if(datosActualizarMedico.documento() != null){
			this.documento = datosActualizarMedico.documento();
		}
		
		if(datosActualizarMedico.direccion() != null){
			this.direccion = direccion.actualizarDatos(datosActualizarMedico.direccion());
		}	
	}

	public void desactivarMedico() {
		this.activo = false;
	}	
}
