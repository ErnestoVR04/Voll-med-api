ALTER TABLE medicos ADD activo tinyint;
UPDATE medicos SET activo = 1;