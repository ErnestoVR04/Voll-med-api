CREATE TABLE  usuarios(
    id BIGINT NOT NULL AUTO_INCREMENT,
    login VARCHAR(100) NOT NULL,
    clave VARCHAR(300) NOT NULL,
    
    PRIMARY KEY (id)
);
